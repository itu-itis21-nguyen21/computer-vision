import numpy as np

# Convert an RGB image into a grayscale image using the NTSC method
def NTSC(img):
    # Create a zero list as the grayscale img with the same shape as img
    grayscale_img = [[0 for _ in range(img.shape[1])] for _ in range(img.shape[0])]

    # Fill the grayscale img list
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            R = img[i][j][0]
            G = img[i][j][1]
            B = img[i][j][2]
            grayscale_img[i][j] = round(0.299 * R + 0.587 * G + 0.114 * B)

    # Convert the list to numpy array
    grayscale_img = np.array(grayscale_img)

    return grayscale_img

# For all pixels p in a grayscale image,
# compute sum of p and sum of p^2
def compute_sums(image):
    s = 0
    s2 = 0
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            p = image[i][j]
            s += p              # sum over all pixels
            s2 += p * p         # sum over all pixels squared
    return (s, s2)

# Compute the mean and variance of all pixel values in a grayscale image
def mean_variance(image):
    # no_of_pixels = no_of_rows * no_of_cols
    no_of_pixels = image.shape[0] * image.shape[1]
    s, s2 = compute_sums(image)
    mean = s / no_of_pixels
    var = s2 / no_of_pixels - mean * mean
    return (mean, var)

# Perform conditional scaling on image J, using reference image I
def conditional_scaling(J, J_mean, J_var, I_mean, I_var):
    # Create a zero list as scaled_J with the same shape as J
    scaled_J = [[0 for _ in range(J.shape[1])] for _ in range(J.shape[0])]

    a = I_mean * J_var / I_var - J_mean
    b = I_var / J_var

    # Conditional scaling
    for i in range(J.shape[0]):
        for j in range(J.shape[1]):
            scaled_J[i][j] = round((a + J[i][j]) * b)

    # Convert J from list to numpy array
    scaled_J = np.array(scaled_J)

    return scaled_J