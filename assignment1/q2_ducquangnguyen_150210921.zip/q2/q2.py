import cv2 as cv
import numpy as np

from functions import *

# Step 1: Read and convert original img into grayscale img J
img = cv.imread("original.png")

# convert img from BGR to RGB
img = img[:, :, ::-1]

# convert into grayscale with the NTSC method
J = NTSC(img)

# save the grayscale image
cv.imwrite("grayscale.png", J)
np.save("original_arr.npy", img)

# Step 2: Read and convert reference img into grayscale reference img I
reference = cv.imread("reference.png")

# convert from BGR to RGB
reference = reference[:, :, ::-1]

# convert into grayscale with the NTSC method
I = NTSC(reference)

# save the grayscale image
cv.imwrite("reference_grayscale.png", I)

# Step 3: Compute mean and variance of J and I
J_mean, J_var = mean_variance(J)
I_mean, I_var = mean_variance(I)

# Step 4: Perform conditional scaling
scaled_J = conditional_scaling(J, J_mean, J_var, I_mean, I_var)

# Optional: print J_mean, J_var, I_mean, I_var, scaled_J_mean, scaled_J_var
#print(f"Mean of J: {J_mean:.2f}, variance of J: {J_var:.2f}")
#print(f"Mean of I: {I_mean:.2f}, variance of I: {I_var:.2f}")
#scaled_J_mean, scaled_J_var = mean_variance(scaled_J)
#print(f"Mean of scaled J: {scaled_J_mean:.2f}, variance of scaled J: {scaled_J_var:.2f}")

cv.imwrite("condition_scaled.png", scaled_J)
np.save("condition_scaled_arr.npy", scaled_J)

