import numpy as np

# Convert an RGB image into a grayscale image using the NTSC method
def NTSC(img):

    # Create a zero list as the grayscale img with the same shape as img
    grayscale_img = [[0 for _ in range(img.shape[1])] for _ in range(img.shape[0])]

    # Fill the grayscale img list
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            R = img[i][j][0]
            G = img[i][j][1]
            B = img[i][j][2]
            grayscale_img[i][j] = round(0.299 * R + 0.587 * G + 0.114 * B)

    # Convert the list to numpy array
    grayscale_img = np.array(grayscale_img)

    return grayscale_img