import cv2 as cv
import numpy as np

from NTSC import NTSC

# Read the image
img = cv.imread("original.png")

# convert img from BGR to RGB
img = img[:, :, ::-1]

# Perform the conversion using the NTSC formula
grayscale_img = NTSC(img)

# Export grayscale_img and save img and grayscale_img arrays to npy files
cv.imwrite("grayscale.png", grayscale_img)
np.save("original_arr.npy", img)
np.save("grayscale_arr.npy", grayscale_img)