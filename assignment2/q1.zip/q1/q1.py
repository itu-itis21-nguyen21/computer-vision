import cv2 as cv
import numpy as np

from functions import *

FILTER_SIZE_3 = 3
FILTER_SIZE_5 = 5

# Position of each channel in RGB order
R = 0
G = 1
B = 2

img = cv.imread("original.jpg")

# convert img from BGR to RGB
img = img[:, :, ::-1]

# Step 1: Convert original RGB img into grayscale img, dtype = uint8
grayscale = NTSC(img)

# export the image and save img and grayscale_img arrays to npy files
cv.imwrite("grayscale.png", grayscale)
np.save("original_arr.npy", img)
np.save("grayscale_arr.npy", grayscale)

# Step 2: Extract each RGB channel into a separate image
imgR = channel_extraction(img, R)
imgG = channel_extraction(img, G)
imgB = channel_extraction(img, B)

cv.imwrite("imgR.png", imgR)
cv.imwrite("imgG.png", imgG)
cv.imwrite("imgB.png", imgB)

# Step 3: Pad and perform box filtering with the 3x3 and 5x5 filters
filtered_grayscale_3 = box_filtering(grayscale, FILTER_SIZE_3)
filtered_imgR_3 = box_filtering(imgR, FILTER_SIZE_3)
filtered_imgG_3 = box_filtering(imgG, FILTER_SIZE_3)
filtered_imgB_3 = box_filtering(imgB, FILTER_SIZE_3)

filtered_grayscale_5 = box_filtering(grayscale, FILTER_SIZE_5)
filtered_imgR_5 = box_filtering(imgR, FILTER_SIZE_5)
filtered_imgG_5 = box_filtering(imgG, FILTER_SIZE_5)
filtered_imgB_5 = box_filtering(imgB, FILTER_SIZE_5)

# Step 4: Merge 1-channel images back to RGB images + convert RGB to BGR
filtered_rgb_3 = channel_merge(filtered_imgR_3, filtered_imgG_3, filtered_imgB_3)
filtered_rgb_5 = channel_merge(filtered_imgR_5, filtered_imgG_5, filtered_imgB_5)

filtered_rgb_3 = filtered_rgb_3[:, :, ::-1]
filtered_rgb_5 = filtered_rgb_5[:, :, ::-1]

# Step 5: Export the results to images and npy files
cv.imwrite("grayscale_filtered_3x3.png", filtered_grayscale_3)
cv.imwrite("rgb_filtered_3x3.png", filtered_rgb_3)
cv.imwrite("grayscale_filtered_5x5.png", filtered_grayscale_5)
cv.imwrite("rgb_filtered_5x5.png", filtered_rgb_5)

np.save("grayscale_filtered_3x3_arr.npy", filtered_grayscale_3)
np.save("grayscale_filtered_5x5_arr.npy", filtered_grayscale_5)
np.save("rgb_filtered_3x3_arr.npy", filtered_rgb_3)
np.save("rgb_filtered_5x5_arr.npy", filtered_rgb_5)
