import cv2 as cv
import numpy as np

from functions import *

MASK_SIZE = 3

img = cv.imread("original.png")

# convert img from BGR to RGB
img = img[:, :, ::-1]

# Step 1: Convert original RGB img into grayscale img, dtype = uint8
grayscale = NTSC(img)
cv.imwrite("grayscale.png", grayscale)
np.save("original_arr.npy", img)

# Step 2: Upsample grayscale by 2
upsampled = upsample(grayscale)
cv.imwrite("upsampled.png", upsampled)
np.save("upsampled_arr.npy", upsampled)

# Step 3: Perform linear interpolation on unknown pixels, 3x3 mask, stride=1
interpolated = linear_interpolation(upsampled, MASK_SIZE)
cv.imwrite("interpolated.png", interpolated)
np.save("interpolated_arr.npy", interpolated)