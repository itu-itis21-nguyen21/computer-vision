import cv2 as cv
import numpy as np

from functions import *

FILTER_SIZE = 3

img = cv.imread("original.jpg")

# convert img from BGR to RGB
img = img[:, :, ::-1]

# Step 1: Convert original RGB img into grayscale img, dtype = uint8
grayscale = NTSC(img)
cv.imwrite("grayscale.png", grayscale)
np.save("original_arr.npy", img)

# Step 2: Pad and perform box filtering with a 3x3 filter
filtered = box_filtering(grayscale, FILTER_SIZE)
cv.imwrite("box_filtered.png", filtered)

# Step 3: Downsample by 2
downsampled = downsample(filtered)
cv.imwrite("downsampled.png", downsampled)
np.save("downsampled_arr.npy", downsampled)