import cv2 as cv
import numpy as np

from functions import *

FILTER_SIZE_3 = 3
# Sobel 2-D kernels
Y_KERNEL = [1, 0, -1, 
            2, 0, -2, 
            1, 0, -1]
X_KERNEL = [1, 2, 1, 
            0, 0, 0, 
            -1, -2, -1]
# Sobel 1-D kernels for y-derivatives
Y_KERNEL_1D_1 = [1, 0, -1,
                 1, 0, -1,
                 1, 0, -1]
Y_KERNEL_1D_2 = [1, 1, 1,
                 2, 2, 2,
                 1, 1, 1]
# Sobel 1-D kernels for x-derivatives
X_KERNEL_1D_1 = [1, 2, 1,
                 1, 2, 1,
                 1, 2, 1]
X_KERNEL_1D_2 = [1, 1, 1,
                 0, 0, 0,
                 -1, -1, -1]

img = cv.imread("original.png")

# convert img from BGR to RGB
img = img[:, :, ::-1]

# Step 1: Convert original RGB img into grayscale img
grayscale = NTSC(img)
cv.imwrite("grayscale.png", grayscale)

# Step 2: Pad + convole with Sobel filters to get x- and y-axis derivatives
x_deriv = filtering(grayscale, FILTER_SIZE_3, X_KERNEL)
y_deriv = filtering(grayscale, FILTER_SIZE_3, Y_KERNEL)
cv.imwrite("x_derivative_output.png", x_deriv)
cv.imwrite("y_derivative_output.png", y_deriv)

# Step 3: Survey the separability of Sobel filters

# Gy = (A * [1 0 -1]) * [1 2 1].T
y_deriv_1d_half = filtering(grayscale, FILTER_SIZE_3, Y_KERNEL_1D_2)
y_deriv_1d = filtering(y_deriv_1d_half, FILTER_SIZE_3, Y_KERNEL_1D_1)

# Gx = (A * [1 2 1]) * [1 0 -1].T
x_deriv_1d_half = filtering(grayscale, FILTER_SIZE_3, X_KERNEL_1D_2)
x_deriv_1d = filtering(x_deriv_1d_half, FILTER_SIZE_3, X_KERNEL_1D_1)

cv.imwrite("x_derivative_1d.png", x_deriv_1d)
cv.imwrite("y_derivative_1d.png", y_deriv_1d)

# Step 4: Compute gradient magnitude
grad_mag = grad_magnitude(x_deriv, y_deriv)
cv.imwrite("gradient_magnitude.png", grad_mag)