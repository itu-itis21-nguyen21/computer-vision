import cv2 as cv
import numpy as np

from functions import *

FILTER_SIZE_3 = 3
FILTER_SIZE_5 = 5
# Gaussian filters of shape 3x3 and 5x5
GAUSSIAN_FILTER_3x3 = [1, 2, 1, 
                       2, 4, 2, 
                       1, 2, 1]
GAUSSIAN_FILTER_5x5 = [1, 4, 6, 4, 1, 
                       4, 16, 24, 16, 4, 
                       6, 24, 36, 24, 6, 
                       4, 16, 24, 16, 4, 
                       1, 4, 6, 4, 1]

img = cv.imread("original.png")

# convert img from BGR to RGB
img = img[:, :, ::-1]

# Step 1: Convert original RGB img into grayscale img, dtype = uint8
grayscale = NTSC(img)
cv.imwrite("grayscale.png", grayscale)

# Step 2: Pad + do Gaussian filtering on 3x3 scale and 5x5 scale
filtered_3 = gaussian_filtering(grayscale, FILTER_SIZE_3, GAUSSIAN_FILTER_3x3, norm_val=16)
filtered_5 = gaussian_filtering(grayscale, FILTER_SIZE_5, GAUSSIAN_FILTER_5x5, norm_val=256)
cv.imwrite("filtered3x3.png", filtered_3)
cv.imwrite("filtered5x5.png", filtered_5)
