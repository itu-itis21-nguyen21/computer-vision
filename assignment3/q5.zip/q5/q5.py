import cv2 as cv
import numpy as np

from functions import *

SOBEL_FILTER_SIZE = 3
# Sobel 2-D kernels
X_KERNEL = [1, 0, -1, 
            2, 0, -2, 
            1, 0, -1]
Y_KERNEL = [1, 2, 1, 
            0, 0, 0, 
            -1, -2, -1]

img = cv.imread("original.png")

# convert img from BGR to RGB
img = img[:, :, ::-1]

# Step 1: Convert original RGB img into grayscale img
grayscale = NTSC(img)
cv.imwrite("grayscale.png", grayscale)

# Step 2: Sobel filtering
x_deriv_sobel = filtering(grayscale, SOBEL_FILTER_SIZE, X_KERNEL)
y_deriv_sobel = filtering(grayscale, SOBEL_FILTER_SIZE, Y_KERNEL)
grad_mag_sobel = grad_magnitude(x_deriv_sobel, y_deriv_sobel)
# Gradient magnitude of img with Sobel kernels
cv.imwrite("grad_mag_sobel.png", grad_mag_sobel)

# Step 2: Sobel filtering
x_deriv_sobel = filtering(grayscale, SOBEL_FILTER_SIZE, X_KERNEL)
y_deriv_sobel = filtering(grayscale, SOBEL_FILTER_SIZE, Y_KERNEL)
grad_mag_sobel = grad_magnitude(x_deriv_sobel, y_deriv_sobel)
# Gradient magnitude of img with Sobel kernels
cv.imwrite("sobel.png", grad_mag_sobel)

# Step 3: Canny edge detection algorithm
# Cast grayscale to uint8 before running cv.Canny()
grayscale = grayscale.astype(np.uint8)
# minVal = 50, maxVal = 100, L2gradient = True
canny1 = cv.Canny(grayscale, 50, 100, L2gradient=True)
cv.imwrite("canny1.png", canny1)
# minVal = 100, maxVal = 200, L2gradient = True
canny2 = cv.Canny(grayscale, 100, 200, L2gradient=True)
cv.imwrite("canny2.png", canny2)