import numpy as np
import math

NO_OF_PADS = 1

# Convert an RGB image into a grayscale image using the NTSC method
def NTSC(img):
    # Create a zero list as the grayscale img with the same shape as img
    grayscale_img = [[0 for _ in range(img.shape[1])] for _ in range(img.shape[0])]

    # Fill the grayscale img list
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            R = img[i][j][0]
            G = img[i][j][1]
            B = img[i][j][2]
            grayscale_img[i][j] = round(0.299 * R + 0.587 * G + 0.114 * B)

    # Convert the list to numpy array
    grayscale_img = np.array(grayscale_img)

    return grayscale_img

# Pad an image with 0
def padding(image, no_of_paddings):
    # Create a zero list as the padded img
    # Size = image size + 2 * no_of_paddings
    padded_img = [[0 for _ in range(image.shape[1] + no_of_paddings * 2)] for _ in range(image.shape[0] + no_of_paddings * 2)]

    # Iterate over image and copy each pixel value of image into the appropriate position of padded_img
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            padded_img[i+no_of_paddings][j+no_of_paddings] = image[i][j]

    # Convert padded img from list to numpy array
    padded_img = np.array(padded_img)
    
    return padded_img

# Filter size F defines a window of size FxF with reference pixel p as window center
# This function returns a LIST of all the pixel values within a window

def define_window(image, reference_row, reference_col, filtersize):
    window_pixels = []

    for i in range(-filtersize//2+1, filtersize//2+1):
        for j in range(-filtersize//2+1, filtersize//2+1):
            window_pixels.append(image[reference_row+i][reference_col+j])

    return window_pixels

# Perform a filtering on an image, stride=1
# 1) Padding the image with 0
# 2) Run a filtering window across the image and perform a filtering operation of any type

def filtering(img, filtersize, filtermatrix):
    # 1) Padding
    padded_img = padding(img, NO_OF_PADS)

    # 2) Filtering
    filtered_img = np.zeros(img.shape)

    # Iterate through each image pixel -> define a window -> matrix multiplication with filtering matrix
    # The range of the for-loop is set to prevent the window from exceeding image border
    for i in range(NO_OF_PADS, padded_img.shape[0]-NO_OF_PADS):  
        for j in range(NO_OF_PADS, padded_img.shape[1]-NO_OF_PADS):
            window_pixels = define_window(padded_img, i, j, filtersize)
            filtered_pixel = 0
            for k in range(len(filtermatrix)):
                filtered_pixel += window_pixels[k] * filtermatrix[k]
            filtered_img[i-NO_OF_PADS][j-NO_OF_PADS] = filtered_pixel

    return filtered_img

# Function to compute the gradient magnitude output from x-derivative and y-derivative
# L2 Norm
def grad_magnitude(x_deriv, y_deriv):
    grad_magnitude = np.zeros(x_deriv.shape)
    for i in range(x_deriv.shape[0]):
        for j in range(x_deriv.shape[1]):
            grad_magnitude[i][j] = math.sqrt(x_deriv[i][j] * x_deriv[i][j] + y_deriv[i][j] * y_deriv[i][j])
    return grad_magnitude