import cv2 as cv
import numpy as np

from functions import *

FILTER_SIZE_3 = 3
# Sobel 2-D kernels
Y_KERNEL = [1, 0, -1, 
            2, 0, -2, 
            1, 0, -1]
X_KERNEL = [1, 2, 1, 
            0, 0, 0, 
            -1, -2, -1]
# Weight kernel to compute gradient covariance matrix M
W = [1, 1, 1,
     1, 1, 1,
     1, 1, 1]

# Hyperparameters
EPSILON = 1e-10
ALPHA = 0.15
HARRIS_THRESHOLD = 1500000
TOMASI_THRESHOLD = 50000
NOBEL_THRESHOLD = 25000

img = cv.imread("original.png")
img = img[:, :, ::-1]       #  convert from BGR to RGB

# STEP 1: Convert to grayscale
grayscale = NTSC(img)

# STEP 2: Pad + convole with Sobel filters to get x- and y-axis derivatives
Ix = filtering(grayscale, FILTER_SIZE_3, X_KERNEL)
Iy = filtering(grayscale, FILTER_SIZE_3, Y_KERNEL)

# STEP 3: Compute derivative product matrices
IxIx = hadamard_product(Ix, Ix)
IxIy = hadamard_product(Ix, Iy)
IyIy = hadamard_product(Iy, Iy)

# STEP 4: Filter each derivate product matrix with a 3x3 mask W
IxIx_w = filtering(IxIx, FILTER_SIZE_3, W)
IxIy_w = filtering(IxIy, FILTER_SIZE_3, W)
IyIy_w = filtering(IyIy, FILTER_SIZE_3, W)

# STEP 5: Compute cornerness measure R using Harris-Stephens, Tomasi-Kanade, and Nobel
# Return a matrix of R for each image pixel
harrisRmatrix = np.zeros(IxIx_w.shape)
tomasiRmatrix = np.zeros(IxIx_w.shape)
nobelRmatrix = np.zeros(IxIx_w.shape)
# Counting change directions
hvchange = 0             # horizontal or vertical
dchange = 0              # diagonal
for i in range(IxIx_w.shape[0]):
    for j in range(IxIx_w.shape[1]):
        # Gradient covariance matrix M
        M = np.array([[IxIx_w[i][j], IxIy_w[i][j]], [IxIy_w[i][j], IyIy_w[i][j]]])
        harrisRmatrix[i][j] = harrisR(M, ALPHA)
        (tomasiRmatrix[i][j], change) = tomasiR(M)
        if change == "hv":
            hvchange += 1
        elif change == "d":
            dchange += 1
        nobelRmatrix[i][j] = nobelR(M, EPSILON)

# STEP 6: Detect and plot the corners on the original image
# Convert img back to BGR
img = img[:, :, ::-1] 
# Duplicate original img array to mark corners on        
harris_corners = np.copy(img)
tomasi_corners = np.copy(img)
nobel_corners = np.copy(img)
# Plotting
plot_corners(harrisRmatrix, harris_corners, HARRIS_THRESHOLD)
plot_corners(tomasiRmatrix, tomasi_corners, TOMASI_THRESHOLD)
plot_corners(nobelRmatrix, nobel_corners, NOBEL_THRESHOLD)
cv.imwrite("harriscorners.png", harris_corners)
cv.imwrite("tomasicorners.png", tomasi_corners)
cv.imwrite("nobelcorners.png", nobel_corners)

# Print the number of horizontal/vertical changes and diagonal changes
#print(f"Number of horizontal or vertical changes: {hvchange}")
#print(f"Number of diagonal changes: {dchange}")