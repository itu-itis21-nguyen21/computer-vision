import numpy as np
import cv2 as cv

NO_OF_PADS = 1
EPSILON = 1e-10         # to avoid dividing by 0

# Convert an RGB image into a grayscale image using the NTSC method
def NTSC(img):
    # Create a zero list as the grayscale img with the same shape as img
    grayscale_img = [[0 for _ in range(img.shape[1])] for _ in range(img.shape[0])]

    # Fill the grayscale img list
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            R = img[i][j][0]
            G = img[i][j][1]
            B = img[i][j][2]
            grayscale_img[i][j] = round(0.299 * R + 0.587 * G + 0.114 * B)

    # Convert the list to numpy array and convert data type to unsigned 8-bit int (0 to 255)
    grayscale_img = np.array(grayscale_img).astype(np.uint8)

    return grayscale_img

# Pad an image with 0

def padding(image, no_of_paddings):
    # Create a zero list as the padded img
    # Size = image size + 2 * no_of_paddings
    padded_img = [[0 for _ in range(image.shape[1] + no_of_paddings * 2)] for _ in range(image.shape[0] + no_of_paddings * 2)]

    # Iterate over image and copy each pixel value of image into the appropriate position of padded_img
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            padded_img[i+no_of_paddings][j+no_of_paddings] = image[i][j]

    # Convert padded img from list to numpy array
    padded_img = np.array(padded_img)
    
    return padded_img

# Filter size F defines a window of size FxF with reference pixel p as window center
# This function returns a LIST of all the pixel values within a window

def define_window(image, reference_row, reference_col, filtersize):
    window_pixels = []

    for i in range(-filtersize//2+1, filtersize//2+1):
        for j in range(-filtersize//2+1, filtersize//2+1):
            window_pixels.append(image[reference_row+i][reference_col+j])

    return window_pixels

# Perform a filtering on an image, stride=1
# 1) Padding the image with 0
# 2) Run a filtering window across the image and perform a filtering operation of any type

def filtering(img, filtersize, filtermatrix):
    # 1) Padding
    padded_img = padding(img, NO_OF_PADS)

    # 2) Filtering
    filtered_img = np.zeros(img.shape)

    # Iterate through each image pixel -> define a window -> matrix multiplication with filtering matrix
    # The range of the for-loop is set to prevent the window from exceeding image border
    for i in range(NO_OF_PADS, padded_img.shape[0]-NO_OF_PADS):  
        for j in range(NO_OF_PADS, padded_img.shape[1]-NO_OF_PADS):
            window_pixels = define_window(padded_img, i, j, filtersize)
            filtered_pixel = 0
            for k in range(len(filtermatrix)):
                filtered_pixel += window_pixels[k] * filtermatrix[k]
            filtered_img[i-NO_OF_PADS][j-NO_OF_PADS] = filtered_pixel

    return filtered_img

# Find Hadamard product of 2 matrices (of the same size)
def hadamard_product(m1, m2):
    product = np.zeros(m1.shape)
    for i in range(m1.shape[0]):
        for j in range(m1.shape[1]):
            product[i][j] = m1[i][j] * m2[i][j]
    return product

# Find cornerness measure R of a matrix M using Harris-Stephens formula
def harrisR(M, alpha):
    determinant = np.linalg.det(M)
    trace = np.trace(M)
    return (determinant - alpha * (trace*trace))

# Find cornerness measure R of a matrix M using Tomasi-Kanade formula
# Find the direction of change (if any)
def tomasiR(M):
    # Compute eigenvalues
    eigenvals = np.linalg.eigvals(M)
    smaller = np.min(eigenvals)
    larger = np.max(eigenvals)
    # Find the change direction
    # 1) Ignore flat regions (both eigenvalues < 1)
    # 2) if (larger / smaller) >= 2 -> horizontal or vertical changes (edges)
    # 3) if (larger / smaller) < 2 -> diagonal change (corners)
    change = "n"                        # no change
    if larger >= 1:
        if (larger / (smaller+EPSILON)) >= 2:
            change = "hv"               # horizontal or vertical change
        else:
            change = "d"                # diagonal change
    # return R and change direction
    return (smaller, change)

# Find cornerness measure R of a matrix M using Nobel formula
def nobelR(M, epsilon):
    determinant = np.linalg.det(M)
    trace = np.trace(M)
    return (determinant / (trace + epsilon))

# Plot corners on image
def plot_corners(R, img, threshold):
    # Look for Corner strengths above the threshold
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            if R[i][j] > threshold:
                max = R[i][j]

                # Local non-maxima suppression
                skip = False
                for row in range(5):
                    for col in range(5):
                        if (i + row - 2 < img.shape[0]) and (j + col - 2 < img.shape[1]):
                            if R[i + row - 2][j + col - 2] > max:
                                skip = True
                                break
                if not skip:
                    # Point is expressed in x, y which is col, row
                    cv.circle(img, (j, i), radius=5, color=(0, 255, 0), thickness=1)


