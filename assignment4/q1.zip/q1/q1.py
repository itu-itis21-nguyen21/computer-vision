import cv2 as cv
import numpy as np

from functions import *

img_clear = cv.imread("Q1.jpg")
img_outliers = cv.imread("Q1_2.jpg")

FILTER_SIZE_3 = 3
# Gaussian filters of shape 3x3
GAUSSIAN_FILTER_3x3 = [1, 2, 1, 
                       2, 4, 2, 
                       1, 2, 1]

# STEP 1: Use 3x3 Gaussian filter to remove noise in the clear image
img_clear = img_clear[:, :, ::-1]       # convert from BGR to RGB
grayscale = NTSC(img_clear)             # convert to grayscale
filtered_3 = gaussian_filtering(grayscale, FILTER_SIZE_3, GAUSSIAN_FILTER_3x3, norm_val=16)

# STEP 2: Use Canny edge detection algorithm to detect edges of the pencil

# Q1.jpg: Clear pencil image
# Threshold 1: min = 40, max = 100
canny_clear_40_100 = cv.Canny(filtered_3, 40, 100, L2gradient=True)
cv.imwrite("canny_clear_40_100.png", canny_clear_40_100)
# Threshold 2: min = 100, max = 220
canny_clear_100_220 = cv.Canny(filtered_3, 100, 220, L2gradient=True)
cv.imwrite("canny_clear_100_220.png", canny_clear_100_220)
# Threshold 3: min = 40, max = 220
canny_clear_40_220 = cv.Canny(filtered_3, 40, 220, L2gradient=True)
cv.imwrite("canny_clear_40_220.png", canny_clear_40_220)

# Threshold 3 (40-220) outputs the best edges in the clear image case

# Q1_2.jpg: Pencil image with outliers
# Threshold 1: min = 40, max = 100
canny_outliers_40_100 = cv.Canny(img_outliers, 40, 100, L2gradient=True)
cv.imwrite("canny_outliers_40_100.png", canny_outliers_40_100)
# Threshold 2: min = 100, max = 220
canny_outliers_100_220 = cv.Canny(img_outliers, 100, 220, L2gradient=True)
cv.imwrite("canny_outliers_100_220.png", canny_outliers_100_220)
# Threshold 3: min = 40, max = 220
canny_outliers_40_220 = cv.Canny(img_outliers, 40, 220, L2gradient=True)
cv.imwrite("canny_outliers_40_220.png", canny_outliers_40_220)

# Threshold 2 (100-220) outputs the best edges in the outlier image case

# STEP 3: Fit a linear equation on the detected edges of 2 images
img_clear_line_fit = draw_line(canny_clear_40_220)
cv.imwrite("clear_img_fitline.png", img_clear_line_fit)
img_outliers_line_fit =draw_line(canny_outliers_100_220)
cv.imwrite("outliers_img_fitline.png", img_outliers_line_fit)


