import numpy as np
import cv2 as cv

# Convert an RGB image into a grayscale image using the NTSC method
def NTSC(img):
    # Create a zero list as the grayscale img with the same shape as img
    grayscale_img = [[0 for _ in range(img.shape[1])] for _ in range(img.shape[0])]

    # Fill the grayscale img list
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            R = img[i][j][0]
            G = img[i][j][1]
            B = img[i][j][2]
            grayscale_img[i][j] = round(0.299 * R + 0.587 * G + 0.114 * B)

    # Convert the list to numpy array and convert data type to unsigned 8-bit int (0 to 255)
    grayscale_img = np.array(grayscale_img).astype(np.uint8)

    return grayscale_img

# Compute the number of paddings needed according to filter size
def no_of_paddings(filtersize):
    return filtersize // 2

# Pad an image with 0
def padding(image, no_of_paddings):
    # Create a zero list as the padded img
    # Size = image size + 2 * no_of_paddings
    padded_img = [[0 for _ in range(image.shape[1] + no_of_paddings * 2)] for _ in range(image.shape[0] + no_of_paddings * 2)]

    # Iterate over image and copy each pixel value of image into the appropriate position of padded_img
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            padded_img[i+no_of_paddings][j+no_of_paddings] = image[i][j]

    # Convert padded img from list to numpy array
    padded_img = np.array(padded_img, dtype=np.uint8)
    
    return padded_img

# Filter size F defines a window of size FxF with reference pixel p as window center
# This function returns a LIST of all the pixel values within a window
def define_window(image, reference_row, reference_col, filtersize):
    window_pixels = []

    for i in range(-filtersize//2+1, filtersize//2+1):
        for j in range(-filtersize//2+1, filtersize//2+1):
            window_pixels.append(image[reference_row+i][reference_col+j])

    return window_pixels

# Perform Gaussian filtering on an image, stride=1
# 1) Padding the image with 0
# 2) Run 3x3/5x5 window throughout the image and perform Gaussian filtering
# The Gaussian filtering window (Gfilter) should be defined as an 1-D list
def gaussian_filtering(img, filtersize, Gfilter, norm_val):
    
    # 1) Padding
    no_of_pads = no_of_paddings(filtersize)
    padded_img = padding(img, no_of_pads)

    # 2) Filtering
    filtered_img = np.zeros(img.shape)

    # Iterate through each image pixel -> define a window -> matrix multiplication with filtering matrix -> normalize
    # The range of the for-loop is set to prevent the window from exceeding image border
    for i in range(no_of_pads, padded_img.shape[0]-no_of_pads):  
        for j in range(no_of_pads, padded_img.shape[1]-no_of_pads):
            window_pixels = define_window(padded_img, i, j, filtersize)
            filtered_pixel = 0
            for k in range(len(Gfilter)):
                filtered_pixel += window_pixels[k] * Gfilter[k]
            filtered_img[i-no_of_pads][j-no_of_pads] = filtered_pixel / norm_val

    # Convert data type to uint8
    filtered_img = filtered_img.astype(dtype=np.uint8)

    return filtered_img

# Collect x- and y-coordinates of edge pixels in a image into 2 separate lists
def edge_pixel_coordinates(eimg):
    detected_x = []                 # list of x-coordinates of all detected edge pixels
    detected_y = []                 # list of y-coordinates of all detected edge pixels
    for i in range(eimg.shape[0]):
        for j in range(eimg.shape[1]):
            if eimg[i][j] != 0:      # if pixel value != 0 -> edge pixel 
                detected_x.append(j)
                detected_y.append(i)
    return (detected_x, detected_y)         # return 2 lists of edge coordinates

# Compute the slope of the best-fitting line and the mean of all edge pixels
# Return format: (slope, mean_x_coordinate, mean_y_coordinate)
def compute_slope_and_mean(eimg):
    # Use edge_pixel_coordinates() to extract the coordinates of all edge pixels in eimg
    (x_coor, y_coor) = edge_pixel_coordinates(eimg)
    # Compute mean_x_coor and mean_y_coor
    mean_x_coor = sum(x_coor)/len(x_coor)
    mean_y_coor = sum(y_coor)/len(y_coor)
    # nominator
    nom = 0    
    # denominator                     
    denom = 0
    for i in range(len(x_coor)):
        nom += (x_coor[i] - mean_x_coor) * (y_coor[i] - mean_y_coor)
        denom += (x_coor[i] - mean_x_coor) * (x_coor[i] - mean_x_coor)
    return (nom / denom, mean_x_coor, mean_y_coor)

# Find point A on a line l, y coordinate of A is given, find its x coordinate
# The line equation is (y-y0)=a(x-x0) where (x0,y0) is a known point on the line
# Find x using the formula: x=(y-y0+ax0)/a 
def compute_x(slope, point, y):
    (x0, y0) = point
    return int((y - y0 + slope*x0) / slope)         # rounding since opencv only accepts discreet position values

# Find point A on a line l, x coordinate of A is given, find its y coordinate
# The line equation is (y-y0)=a(x-x0) where (x0,y0) is a known point on the line
# Find y using the formula: y=ax+y0-ax0 
def compute_y(slope, point, x):
    (x0, y0) = point
    return int(slope*x + y0 - slope*x0)             # rounding since opencv only accepts discreet position values

def draw_line(eimg):
    # Compute the slope of the best fit line and the mean of edge pixels
    # Slope and the mean point will define this best fit line
    (slope, mean_x, mean_y) = compute_slope_and_mean(eimg)
    
    # Find where the line intersects the border (it should intersect at 2 points)
    # These 2 points will be used to draw the line using cv2.line()
    
    # Lower side of the image
    min_border = 0
    # The line either hits the width side (x axis) or the height side (y axis) of the image
    # We can compute 2 intersection points at these 2 axes and find which one doesn't exceed the image border
    drawpt1 = (compute_x(slope, (mean_x,mean_y), y=0), 0)
    if (drawpt1[0] < 0):
        drawpt1 = (0, compute_y(slope, (mean_x, mean_y), x=0))

    # Upper side of the image
    # Since the image can be rectangular, there are 2 max border values for x and y axes, corresponding to the image shape
    max_border_x = eimg.shape[1]
    max_border_y = eimg.shape[0]
    # Again, we compute 2 intersection points and choose the one which doesn't exceed the border
    drawpt2 = (compute_x(slope, (mean_x,mean_y), y=max_border_y), max_border_y)
    if (drawpt2[0] > max_border_x):
        drawpt2 = (max_border_x, compute_y(slope, (mean_x, mean_y), x=max_border_x))
    # Draw
    return cv.line(eimg, pt1=drawpt1, pt2=drawpt2, color=(255, 255, 255), thickness=1)

