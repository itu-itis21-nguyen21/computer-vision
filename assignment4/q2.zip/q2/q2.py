import cv2 as cv
import numpy as np

from functions import *

img_clear = cv.imread("Q1.jpg")
img_outliers = cv.imread("Q1_2.jpg")

FILTER_SIZE_3 = 3
# Gaussian filters of shape 3x3
GAUSSIAN_FILTER_3x3 = [1, 2, 1, 
                       2, 4, 2, 
                       1, 2, 1]

# STEP 1: Use 3x3 Gaussian filter to remove noise in the clear image
img_clear = img_clear[:, :, ::-1]       # convert from BGR to RGB
grayscale = NTSC(img_clear)             # convert to grayscale
filtered_3 = gaussian_filtering(grayscale, FILTER_SIZE_3, GAUSSIAN_FILTER_3x3, norm_val=16)

# STEP 2: Use Canny edge detection algorithm to detect edges of the pencil
# Q1.jpg: Clear pencil image
# Threshold: min = 40, max = 220
canny_clear_40_220 = cv.Canny(filtered_3, 40, 220, L2gradient=True)
cv.imwrite("canny_clear_40_220.png", canny_clear_40_220)
# Q1_2.jpg: Pencil image with outliers
# Threshold 2: min = 100, max = 220
canny_outliers_100_220 = cv.Canny(img_outliers, 100, 220, L2gradient=True)
cv.imwrite("canny_outliers_100_220.png", canny_outliers_100_220)

# STEP 3: Hough line transform
# Copy original images to plot Hough lines on (3 copies for 3 threshold values)
houghlines_clear1 = np.copy(img_clear)
houghlines_clear2 = np.copy(img_clear)
houghlines_clear3 = np.copy(img_clear)
houghlines_outliers1 = np.copy(img_outliers)
houghlines_outliers2 = np.copy(img_outliers)
houghlines_outliers3 = np.copy(img_outliers)

# Clear image - 3 thresholds 200, 100, 50
lines = cv.HoughLines(canny_clear_40_220, rho=1, theta=np.pi/180, threshold=200)
for line in lines:
    rho,theta = line[0]
    a = np.cos(theta)
    b = np.sin(theta)
    x0 = a*rho
    y0 = b*rho
    x1 = int(x0 + 1000*(-b))
    y1 = int(y0 + 1000*(a))
    x2 = int(x0 - 1000*(-b))
    y2 = int(y0 - 1000*(a))
    cv.line(houghlines_clear1,(x1,y1),(x2,y2), (255,0,0), 1)
houghlines_clear1 = houghlines_clear1[:, :, ::-1]       # convert back from RGB to BGR to output image
cv.imwrite("houghlines_clear200.png", houghlines_clear1)

lines = cv.HoughLines(canny_clear_40_220, rho=1, theta=np.pi/180, threshold=100)
for line in lines:
    rho,theta = line[0]
    a = np.cos(theta)
    b = np.sin(theta)
    x0 = a*rho
    y0 = b*rho
    x1 = int(x0 + 1000*(-b))
    y1 = int(y0 + 1000*(a))
    x2 = int(x0 - 1000*(-b))
    y2 = int(y0 - 1000*(a))
    cv.line(houghlines_clear2,(x1,y1),(x2,y2), (255,0,0), 1)
houghlines_clear2 = houghlines_clear2[:, :, ::-1]       # convert back from RGB to BGR to output image
cv.imwrite("houghlines_clear100.png", houghlines_clear2)

lines = cv.HoughLines(canny_clear_40_220, rho=1, theta=np.pi/180, threshold=50)
for line in lines:
    rho,theta = line[0]
    a = np.cos(theta)
    b = np.sin(theta)
    x0 = a*rho
    y0 = b*rho
    x1 = int(x0 + 1000*(-b))
    y1 = int(y0 + 1000*(a))
    x2 = int(x0 - 1000*(-b))
    y2 = int(y0 - 1000*(a))
    cv.line(houghlines_clear3,(x1,y1),(x2,y2), (255,0,0), 1)
houghlines_clear3 = houghlines_clear3[:, :, ::-1]       # convert back from RGB to BGR to output image
cv.imwrite("houghlines_clear50.png", houghlines_clear3)

# Image with outliers - 3 thresholds 200, 100, 50
lines = cv.HoughLines(canny_outliers_100_220, rho=1, theta=np.pi/180, threshold=200)
for line in lines:
    rho,theta = line[0]
    a = np.cos(theta)
    b = np.sin(theta)
    x0 = a*rho
    y0 = b*rho
    x1 = int(x0 + 1000*(-b))
    y1 = int(y0 + 1000*(a))
    x2 = int(x0 - 1000*(-b))
    y2 = int(y0 - 1000*(a))
    cv.line(houghlines_outliers1,(x1,y1),(x2,y2), (0,0,255), 1)
cv.imwrite("houghlines_outliers200.png", houghlines_outliers1)

lines = cv.HoughLines(canny_outliers_100_220, rho=1, theta=np.pi/180, threshold=100)
for line in lines:
    rho,theta = line[0]
    a = np.cos(theta)
    b = np.sin(theta)
    x0 = a*rho
    y0 = b*rho
    x1 = int(x0 + 1000*(-b))
    y1 = int(y0 + 1000*(a))
    x2 = int(x0 - 1000*(-b))
    y2 = int(y0 - 1000*(a))
    cv.line(houghlines_outliers2,(x1,y1),(x2,y2), (0,0,255), 1)
cv.imwrite("houghlines_outliers100.png", houghlines_outliers2)

lines = cv.HoughLines(canny_outliers_100_220, rho=1, theta=np.pi/180, threshold=50)
for line in lines:
    rho,theta = line[0]
    a = np.cos(theta)
    b = np.sin(theta)
    x0 = a*rho
    y0 = b*rho
    x1 = int(x0 + 1000*(-b))
    y1 = int(y0 + 1000*(a))
    x2 = int(x0 - 1000*(-b))
    y2 = int(y0 - 1000*(a))
    cv.line(houghlines_outliers3,(x1,y1),(x2,y2), (0,0,255), 1)
cv.imwrite("houghlines_outliers50.png", houghlines_outliers3)
