import numpy as np
import cv2 as cv

# Convert an RGB image into a grayscale image using the NTSC method
def NTSC(img):
    # Create a zero list as the grayscale img with the same shape as img
    grayscale_img = [[0 for _ in range(img.shape[1])] for _ in range(img.shape[0])]

    # Fill the grayscale img list
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            R = img[i][j][0]
            G = img[i][j][1]
            B = img[i][j][2]
            grayscale_img[i][j] = round(0.299 * R + 0.587 * G + 0.114 * B)

    # Convert the list to numpy array and convert data type to unsigned 8-bit int (0 to 255)
    grayscale_img = np.array(grayscale_img).astype(np.uint8)

    return grayscale_img

# Compute the number of paddings needed according to filter size
def no_of_paddings(filtersize):
    return filtersize // 2

# Pad an image with 0
def padding(image, no_of_paddings):
    # Create a zero list as the padded img
    # Size = image size + 2 * no_of_paddings
    padded_img = [[0 for _ in range(image.shape[1] + no_of_paddings * 2)] for _ in range(image.shape[0] + no_of_paddings * 2)]

    # Iterate over image and copy each pixel value of image into the appropriate position of padded_img
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            padded_img[i+no_of_paddings][j+no_of_paddings] = image[i][j]

    # Convert padded img from list to numpy array
    padded_img = np.array(padded_img, dtype=np.uint8)
    
    return padded_img

# Filter size F defines a window of size FxF with reference pixel p as window center
# This function returns a LIST of all the pixel values within a window
def define_window(image, reference_row, reference_col, filtersize):
    window_pixels = []

    for i in range(-filtersize//2+1, filtersize//2+1):
        for j in range(-filtersize//2+1, filtersize//2+1):
            window_pixels.append(image[reference_row+i][reference_col+j])

    return window_pixels

# Perform Gaussian filtering on an image, stride=1
# 1) Padding the image with 0
# 2) Run 3x3/5x5 window throughout the image and perform Gaussian filtering
# The Gaussian filtering window (Gfilter) should be defined as an 1-D list
def gaussian_filtering(img, filtersize, Gfilter, norm_val):
    
    # 1) Padding
    no_of_pads = no_of_paddings(filtersize)
    padded_img = padding(img, no_of_pads)

    # 2) Filtering
    filtered_img = np.zeros(img.shape)

    # Iterate through each image pixel -> define a window -> matrix multiplication with filtering matrix -> normalize
    # The range of the for-loop is set to prevent the window from exceeding image border
    for i in range(no_of_pads, padded_img.shape[0]-no_of_pads):  
        for j in range(no_of_pads, padded_img.shape[1]-no_of_pads):
            window_pixels = define_window(padded_img, i, j, filtersize)
            filtered_pixel = 0
            for k in range(len(Gfilter)):
                filtered_pixel += window_pixels[k] * Gfilter[k]
            filtered_img[i-no_of_pads][j-no_of_pads] = filtered_pixel / norm_val

    # Convert data type to uint8
    filtered_img = filtered_img.astype(dtype=np.uint8)

    return filtered_img